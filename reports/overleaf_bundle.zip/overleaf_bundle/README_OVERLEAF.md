# Overleaf upload bundle

This folder is a self-contained LaTeX project ready to upload to Overleaf.

## Contents

- `main.tex` — the report, ported from `reports/REPORT.md` via pandoc.
- `figures/` — all 19 PNG figures referenced in the report.

## How to open in Overleaf

1. Compress this folder into a single `.zip` (if it isn't already).
2. Sign in to <https://www.overleaf.com>.
3. Click **New Project → Upload Project** and select the `.zip`.
4. Overleaf will unpack the project. The main document is `main.tex`.
5. The recommended compiler is **pdfLaTeX** (default). If you switch to XeLaTeX or LuaLaTeX, the document will still compile but may render some Unicode characters slightly differently.

## How to push to an existing Overleaf project (alternative)

If you already have an Overleaf project and want to push these files into it via git:

```bash
# from inside this folder
git init -b main
git add main.tex figures/ README_OVERLEAF.md
git commit -m "Initial: import guidewire-pose final report"

# Get the project's git URL from Overleaf:
#   Menu (top-left) → Git → "Clone with HTTPS"
git remote add overleaf https://git.overleaf.com/<PROJECT_ID>
git push -u overleaf main
```

(Overleaf will prompt for your Overleaf account email and a "Git authentication token", which you generate at Account → Account Settings → Git Integration.)

## Editing

- All figures are at relative path `figures/<name>.png`, so they will render correctly in Overleaf's preview without further configuration.
- The document class is `article`, fontsize 11pt, letter paper, 1-inch margins.
- The table of contents and section numbering are generated automatically.

## If you want a different template (NeurIPS, IEEE, ACM, etc.)

The simplest path is to keep the body of `main.tex` (everything between `\begin{document}` and `\end{document}`) and swap the preamble at the top for the template you want. The body uses only `\section{...}`, `\subsection{...}`, `\includegraphics[...]`, `\begin{longtable}{...}` etc., all of which work unchanged across templates.
